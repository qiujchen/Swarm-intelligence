
%%
clear
clc
close all
dim = 20; % 维度，可选 10, 20
number= 1;  % 函数名： 1 - 12
[lower_bound,upper_bound,variables_no,fobj] = Get_Functions_cec2022(number,dim);
pop_size=100;                      % population members 
max_iter=1000;                  % maximum number of iteration

%% COA
[best_fun,best_position,COA_convergence_curve]=COA(pop_size,max_iter,lower_bound,upper_bound,variables_no,fobj);
display(['The best optimal value of the objective funciton found by COA  for ' [num2str(number)],'  is : ', num2str(best_fun)]);
fprintf ('Best solution obtained by COA: %s\n', num2str(best_position,'%e  '));
%% GMO
[best_fun,best_position,GMO_convergence_curve]=GMO(pop_size,max_iter,lower_bound,upper_bound,variables_no,fobj);
display(['The best optimal value of the objective funciton found by GMO  for ' [num2str(number)],'  is : ', num2str(best_fun)]);
fprintf ('Best solution obtained by GMO: %s\n', num2str(best_position','%e  '));
%% OMA
[Silverback_Score,Silverback,OMA_convergence_curve]=OMA(pop_size,max_iter,lower_bound,upper_bound,variables_no,fobj);
display(['The best optimal value of the objective funciton found by OMA  for ' [num2str(number)],'  is : ', num2str(Silverback_Score)]);
fprintf ('Best solution obtained by OMA: %s\n', num2str(Silverback,'%e  '));
%% WOA
[WOA_Score,WOA,WOA_convergence_curve]=WOA(pop_size,max_iter,lower_bound,upper_bound,variables_no,fobj);
display(['The best optimal value of the objective funciton found by WOA  for ' [num2str(number)],'  is : ', num2str(WOA_Score)]);
fprintf ('Best solution obtained by WOA: %s\n', num2str(WOA,'%e  '));
%% WWPA
[WWPA_Score,WWPA,WWPA_convergence_curve]=WWPA(pop_size,max_iter,lower_bound,upper_bound,variables_no,fobj);
display(['The best optimal value of the objective funciton found by WWPA  for ' [num2str(number)],'  is : ', num2str(WWPA_Score)]);
fprintf ('Best solution obtained by WWPA: %s\n', num2str(WWPA,'%e  '));
%% GOA
[GOA_Score,GOA,GOA_convergence_curve]=GOA(pop_size,max_iter,lower_bound,upper_bound,variables_no,fobj);
display(['The best optimal value of the objective funciton found by GOA  for ' [num2str(number)],'  is : ', num2str(GOA_Score)]);
fprintf ('Best solution obtained by GOA: %s\n', num2str(GOA,'%e  '));
%% GWCA
[GWCA_Score,GWCA,GWCA_convergence_curve]=GWCA(pop_size,max_iter,lower_bound,upper_bound,variables_no,fobj);
display(['The best optimal value of the objective funciton found by GWCA  for ' [num2str(number)],'  is : ', num2str(GWCA_Score)]);
fprintf ('Best solution obtained by GWCA: %s\n', num2str(GWCA,'%e  '));
%% CDO
[CDO_Score,CDO,CDO_convergence_curve]=CDO(pop_size,max_iter,lower_bound,upper_bound,variables_no,fobj);
display(['The best optimal value of the objective funciton found by CDO  for ' [num2str(number)],'  is : ', num2str(CDO_Score)]);
fprintf ('Best solution obtained by CDO: %s\n', num2str(CDO,'%e  '));
%% GRO
[GRO_Score,GRO,GRO_convergence_curve]=GRO(pop_size,max_iter,lower_bound,upper_bound,variables_no,fobj);
display(['The best optimal value of the objective funciton found by GRO  for ' [num2str(number)],'  is : ', num2str(GRO_Score)]);
fprintf ('Best solution obtained by GRO: %s\n', num2str(GRO,'%e  '));

%% RIME
[RIME_Score,RIME,RIME_convergence_curve]=RIME(pop_size,max_iter,lower_bound,upper_bound,variables_no,fobj);
display(['The best optimal value of the objective funciton found by RIME  for ' [num2str(number)],'  is : ', num2str(RIME_Score)]);
fprintf ('Best solution obtained by RIME: %s\n', num2str(RIME,'%e  '));
%% SABO
[SABO_Score,SABO,SABO_convergence_curve]=SABO(pop_size,max_iter,lower_bound,upper_bound,variables_no,fobj);
display(['The best optimal value of the objective funciton found by SABO  for ' [num2str(number)],'  is : ', num2str(SABO_Score)]);
fprintf ('Best solution obtained by SABO: %s\n', num2str(SABO,'%e  '));
%% SAO
[SAO_Score,SAO,SAO_convergence_curve]=SAO(pop_size,max_iter,lower_bound,upper_bound,variables_no,fobj);
display(['The best optimal value of the objective funciton found by SAO  for ' [num2str(number)],'  is : ', num2str(SAO_Score)]);
fprintf ('Best solution obtained by SAO: %s\n', num2str(SAO,'%e  '));
%% ILA
[Bests,n_it_phase1,n_it_phase2,n_it_phase3,costs1,costs2,costs3] = ILA (pop_size,max_iter,lower_bound,upper_bound,variables_no,fobj);
y=zeros(max_iter,1);
for i = 1:max_iter
    y(i,1) = Bests(i).Cost;   
end
ILA_convergence_curve = y;
display(['The best optimal value of the objective funciton found by ILA  for ' [num2str(number)],'  is : ', num2str(ILA_convergence_curve(max_iter))]);
fprintf ('Best solution obtained by ILA: %s\n', num2str(Bests(max_iter).NL,'%e  '));
 

 %% Figure
figure
iter=1:1:max_iter;

    semilogy(iter,COA_convergence_curve,'m','linewidth',1);
    hold on
    semilogy(iter,GMO_convergence_curve,'k','linewidth',1);
    hold on
    semilogy(iter,WOA_convergence_curve,'b','linewidth',1);
    hold on
    semilogy(iter,WWPA_convergence_curve,'r','linewidth',1);
    hold on
    semilogy(iter,OMA_convergence_curve,'g','linewidth',1);
    hold on
    semilogy(iter,GOA_convergence_curve,'y','linewidth',1);
    hold on
    semilogy(iter,GWCA_convergence_curve,'c','linewidth',1);
    hold on
    semilogy(iter,CDO_convergence_curve,'color',[0 0.4470 0.7410],'linewidth',1);
    hold on
    semilogy(iter,GRO_convergence_curve,'color',[0.8500 0.3250 0.0980],'linewidth',1);
    hold on
    semilogy(iter,ILA_convergence_curve,'color',[0.9290 0.6940 0.1250],'linewidth',1);
    hold on
    semilogy(iter,RIME_convergence_curve,'color',[0.4940 0.1840 0.5560],'linewidth',1);
    hold on
    semilogy(iter,SABO_convergence_curve,'color',[0.4660 0.6740 0.1880],'linewidth',1);
    hold on
    semilogy(iter,SAO_convergence_curve,'color',[0.3010 0.7450 0.9330],'linewidth',1);

grid on;
title('收敛曲线')
xlabel('迭代次数');
ylabel('适应度值');
box on
legend('COA','GMO','WOA','WWPA','OMA','GOA','GWCA','CDO','GRO','ILA','RIME','SABO','SAO')
set (gcf,'position', [300,300,600,330])
