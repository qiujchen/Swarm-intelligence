% Cite this article
%Abdulhameed, S., Rashid, T.A. Child Drawing Development Optimization Algorithm Based on Child’s Cognitive Development.
%Arab J Sci Eng (2021). https://doi.org/10.1007/s13369-021-05928-6
%
%
function [Best_pos ,Best_score, BestCosts] = CCD(nPop,MaxIt,lb,ub,dim,fobj)

nVar = dim;                                                            % Number of Unknown (Decision) Variables

VarSize = [1 nVar];                                                    % Matrix Size of Decision Variables
VarMin = round(lb(1));                                                    % Lower Bound of Decision Variables
VarMax = round(ub(1));                     % Upper Bound of Decision Variables

LR=0.01 ;                                % child level rate
SR=0.9;                                  % Child skill rate

PS=10;                                   % pattern matrix size % Constriction Coefficients
%   MaxGR = 0.2*(VarMax-VarMin);             % Max boundery for Golden ratio
%   MinGR = -MaxGR;                          % Min boundery for Golden ratio
CR=0.1;                                  % Creativity Rate
 
ncount=0;
%% Initialization
% The child Template
empty_child.Drawing = [];
empty_child.GR = [];
empty_child.Cost = [];
empty_child.Best.Drawing = [];
empty_child.Best.Cost = [];

empty_int.Drawing = [];
empty_int.Cost = [];
% Initialize Global Best
GlobalBest.Cost = inf;

% Create Population Array
child = repmat(empty_child, nPop, 1);
CP=repmat(empty_child,PS,1);


% Initialize Population Members
for i=1:nPop
    p1=randi([1 nVar]);
    p2=randi([1 nVar]);
    p3 =randi([1 nVar]);

    % Generate Random Solution
    child(i).Drawing = unifrnd(VarMin, VarMax, VarSize); % child get started drawing (random and movemnet)

    % Initialize Golden ratio
    child(i).GR=child(i).Drawing(1,p2)+child(i).Drawing(1,p3)/child(i).Drawing(1,p2);

    % Evaluation
    child(i).Cost = fobj(child(i).Drawing);

    % Update the Personal Best
    child(i).Best.Drawing = child(i).Drawing;
    child(i).Best.Cost = child(i).Cost;

    % Update Global Best
    if child(i).Best.Cost < GlobalBest.Cost
        GlobalBest = child(i).Best;
    end
end

% Array to Hold Best Cost Value on Each Iteration (best Solution in each it
BestCosts = zeros(MaxIt, 1);
[~, SortOrder]=sort([child.Cost]);
for o=1:PS
    CP(o)=child(SortOrder(o));
end
k=randi([1 PS]);
for it=1:MaxIt

    for i=1:nPop
        T=randi([VarMin VarMax],1);
        p1=randi([1 nVar]);
        p2=randi([1 nVar]);
        p3 =randi([1 nVar]);

        if (child(i).Drawing(1,p1)<=T)
            % Update the drawings
            child(i).Drawing = child(i).GR ...
                + SR*rand(VarSize).*(child(i).Best.Drawing - child(i).Drawing) ...
                +LR*rand(VarSize).*(GlobalBest.Drawing - child(i).Drawing);
            LR = randi([6,10])/10;
            SR = randi([6,10])/10;
            % Consider the learnt patterns (||child(i).Drawing(1,p1)>T)
        elseif ( 1.5 <child(i).GR<2  )
            child(i).Drawing= CP(k).Drawing -CR*child(i).Best.Drawing ;
            LR = randi([0,5])/10;
            SR = randi([0,5])/10;
            ncount=ncount+1;
        end
        %
        %                 CR=randi([0,10])/10;
        % Evaluation
        child(i).Cost = fobj(child(i).Drawing);

        % Update Personal Best
        if child(i).Cost < child(i).Best.Cost

            child(i).Best.Drawing = child(i).Drawing;
            child(i).Best.Cost = child(i).Cost;
            % Update Global Best
            if child(i).Best.Cost < GlobalBest.Cost
                GlobalBest = child(i).Best;
                CP(k)= child(i);
            end
        end
    end
    % Store the Best Cost Value
    BestCosts(it) = GlobalBest.Cost;

    BestSol = GlobalBest;

    % Display Iteration Information
%     if mod(it,100) == 0
%         % disp(['CCD Iteration ' num2str(it) ': Best Cost = ' num2str(BestCosts(it))]);
%         disp(['CCD current iteration is: ',num2str(it), ', best fitness is: ', num2str(BestCosts(it))]);
%     end
end

Best_pos = BestSol.Drawing;
Best_score = BestSol.Cost;

end
