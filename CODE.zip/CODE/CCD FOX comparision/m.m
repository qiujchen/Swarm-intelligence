clc;
clear all;
close all;
 
%%  ѡ����
Function_name=1; % �������� 1 - 10
% lb->���ޣ�ub->���ޣ�fobj->Ŀ�꺯����dim-> ά��
[lb,ub,dim,fobj] = Get_Functions_cec2019(Function_name);
pop = 20;%��Ⱥ����
maxIter = 200;%����������

Times = 30;

Times_GWO31_Best_Pos=zeros(Times,dim);
Times_GWO31_Best_fitness=zeros(Times,1);
Times_GWO31_IterCurve=zeros(Times,maxIter);

Times_FOX_Best_Pos=zeros(Times,dim);
Times_FOX_Best_fitness=zeros(Times,1);
Times_FOX_IterCurve=zeros(Times,maxIter);

% Times_FDO_Best_Pos=zeros(Times,dim);
% Times_FDO_Best_fitness=zeros(Times,1);
% Times_FDO_IterCurve=zeros(Times,maxIter);

Times_CCD_Best_Pos=zeros(Times,dim);
Times_CCD_Best_fitness=zeros(Times,1);
Times_CCD_IterCurve=zeros(Times,maxIter);
tic
for i=1:Times
    [Times_GWO31_Best_Pos(i,:),Times_GWO31_Best_fitness(i,:),Times_GWO31_IterCurve(i,:)] = GWO31(pop,dim,ub,lb,fobj,maxIter);
end
toc
disp(['GWO31����ʱ��:',num2str(toc)]);
tic
 for i=1:Times
       [Times_FOX_Best_Pos(i,:),Times_FOX_Best_fitness(i,:),Times_FOX_IterCurve(i,:)] = FOX(pop,maxIter,lb,ub,dim,fobj);
 end
 toc
disp(['FOX����ʱ��:',num2str(toc)]);
% tic
%  for i=1:Times
%       [Times_FDO_Best_Pos(i,:),Times_FDO_Best_fitness(i,:),Times_FDO_IterCurve(i,:)] = FDO(pop,maxIter,lb,ub,dim,fobj);
%  end
%  toc
% disp(['FDO����ʱ��:',num2str(toc)]);
tic
 for i=1:Times
      [Times_CCD_Best_Pos(i,:),Times_CCD_Best_fitness(i,:),Times_CCD_IterCurve(i,:)] = CCD(pop,maxIter,lb,ub,dim,fobj);
 end
toc
disp(['CCD����ʱ��:',num2str(toc)]);
 
GWO31_Best_Pos=mean(Times_GWO31_Best_Pos,1);
GWO31_Best_fitness=mean(log(Times_GWO31_Best_fitness)/log(10),1);
GWO31_IterCurve=mean(log(Times_GWO31_IterCurve)/log(10),1);
 
FOX_Best_Pos=mean(Times_FOX_Best_Pos,1);
FOX_Best_fitness=mean(log(Times_FOX_Best_fitness)/log(10),1);
FOX_IterCurve=mean(log(Times_FOX_IterCurve)/log(10),1);

% FDO_Best_Pos=mean(Times_FDO_Best_Pos,1);
% FDO_Best_fitness=mean(log(Times_FDO_Best_fitness)/log(10),1);
% FDO_IterCurve=mean(log(Times_FDO_IterCurve)/log(10),1);

CCD_Best_Pos=mean(Times_CCD_Best_Pos,1);
CCD_Best_fitness=mean(log(Times_CCD_Best_fitness)/log(10),1);
CCD_IterCurve=mean(log(Times_CCD_IterCurve)/log(10),1);

% 

GWO31_MIN_MAX_MEAN_BZC =[min(Times_GWO31_Best_fitness),max(Times_GWO31_Best_fitness),mean(Times_GWO31_Best_fitness),std(Times_GWO31_Best_fitness)];
%

FOX_MIN_MAX_MEAN_BZC =[min(Times_FOX_Best_fitness),max(Times_FOX_Best_fitness),mean(Times_FOX_Best_fitness),std(Times_FOX_Best_fitness)];
%
% FDO_MIN_MAX_MEAN_BZC =[min(Times_FDO_Best_fitness),max(Times_FDO_Best_fitness),mean(Times_FDO_Best_fitness),std(Times_FDO_Best_fitness)];
%
CCD_MIN_MAX_MEAN_BZC =[min(Times_CCD_Best_fitness),max(Times_CCD_Best_fitness),mean(Times_CCD_Best_fitness),std(Times_CCD_Best_fitness)];
F_CEC_MIN_MAX_MEAN_BZC=[GWO31_MIN_MAX_MEAN_BZC;FOX_MIN_MAX_MEAN_BZC;CCD_MIN_MAX_MEAN_BZC];


% 
disp(['GWO31_MIN_MAX_MEAN_BZC:',GWO31_MIN_MAX_MEAN_BZC]);

disp(['FOX_MIN_MAX_MEAN_BZC:',FOX_MIN_MAX_MEAN_BZC]);

% disp(['FDO_MIN_MAX_MEAN_BZC:',FDO_MIN_MAX_MEAN_BZC]);

disp(['CCD_MIN_MAX_MEAN_BZC:',CCD_MIN_MAX_MEAN_BZC]);


