clc;
clear all;
close all;

Function_name=2; 
[lb,ub,dim,fobj] = Get_Functions_cec2019(Function_name);
pop = 20;
vmax=20;
vmin=-vmax;
vmax = vmax*linspace(1,1,dim);
vmin = vmin*linspace(1,1,dim);
maxIter = 200;
Times = 30;
Times_MVO_Best_Pos=zeros(Times,dim);
Times_MVO_Best_fitness=zeros(Times,1);
Times_MVO_IterCurve=zeros(Times,maxIter);
Times_GSA_Best_Pos=zeros(Times,dim);
Times_GSA_Best_fitness=zeros(Times,1);
Times_GSA_IterCurve=zeros(Times,maxIter);
Times_TSA_Best_Pos=zeros(Times,dim);
Times_TSA_Best_fitness=zeros(Times,1);
Times_TSA_IterCurve=zeros(Times,maxIter);
Times_WDO_Best_Pos=zeros(Times,dim);
Times_WDO_Best_fitness=zeros(Times,1);
Times_WDO_IterCurve=zeros(Times,maxIter);
Times_GWO_Best_Pos=zeros(Times,dim);
Times_GWO_Best_fitness=zeros(Times,1);
Times_GWO_IterCurve=zeros(Times,maxIter);
Times_CDO_Best_fitness=zeros(Times,1);
Times_CDO_IterCurve=zeros(Times,maxIter);
Times_OMA_Best_fitness=zeros(Times,1);
Times_OMA_IterCurve=zeros(Times,maxIter);
Times_GWO31_Best_Pos=zeros(Times,dim);
Times_GWO31_Best_fitness=zeros(Times,1);
Times_GWO31_IterCurve=zeros(Times,maxIter);

for i=1:Times
    disp(i);
    [Times_MVO_Best_Pos(i,:),Times_MVO_Best_fitness(i,:),Times_MVO_IterCurve(i,:)] = MVO(pop,dim,ub,lb,fobj,maxIter);
    [Times_GSA_Best_Pos(i,:),Times_GSA_Best_fitness(i,:),Times_GSA_IterCurve(i,:)] = GSA(pop,dim,ub,lb,fobj,maxIter);
    [Times_WDO_Best_Pos(i,:),Times_WDO_Best_fitness(i,:),Times_WDO_IterCurve(i,:)] = WDO(pop,dim,ub,lb,fobj,maxIter);
    [Times_GWO_Best_Pos(i,:),Times_GWO_Best_fitness(i,:),Times_GWO_IterCurve(i,:)] = GWO(pop,dim,ub,lb,fobj,maxIter);
    [Times_CDO_Best_fitness(i,:),Times_CDO_Best_Pos(i,:),Times_CDO_IterCurve(i,:)] = CDO(pop,maxIter,lb,ub,dim,fobj);
    [Times_OMA_Best_fitness(i,:),Times_OMA_Best_Pos(i,:),Times_OMA_IterCurve(i,:)] = OMA(pop,maxIter,lb,ub,dim,fobj);
    [Times_GWO31_Best_Pos(i,:),Times_GWO31_Best_fitness(i,:),Times_GWO31_IterCurve(i,:)] = GWO31(pop,dim,ub,lb,fobj,maxIter);
 end

MVO_Best_Pos=mean(Times_MVO_Best_Pos,1);
MVO_Best_fitness=mean(log(Times_MVO_Best_fitness)/log(10),1);
MVO_IterCurve=mean(log(Times_MVO_IterCurve)/log(10),1);
GSA_Best_Pos=mean(Times_GSA_Best_Pos,1);
GSA_Best_fitness=mean(log(Times_GSA_Best_fitness)/log(10),1);
GSA_IterCurve=mean(log(Times_GSA_IterCurve)/log(10),1);
TSA_Best_Pos=mean(Times_TSA_Best_Pos,1);
TSA_Best_fitness=mean(log(Times_TSA_Best_fitness)/log(10),1);
TSA_IterCurve=mean(log(Times_TSA_IterCurve)/log(10),1);
WDO_Best_Pos=mean(Times_WDO_Best_Pos,1);
WDO_Best_fitness=mean(log(Times_WDO_Best_fitness)/log(10),1);
WDO_IterCurve=mean(log(Times_WDO_IterCurve)/log(10),1);
GWO_Best_Pos=mean(Times_GWO_Best_Pos,1);
GWO_Best_fitness=mean(log(Times_GWO_Best_fitness)/log(10),1);
GWO_IterCurve=mean(log(Times_GWO_IterCurve)/log(10),1);
CDO_Best_Pos=mean(Times_CDO_Best_Pos,1);
CDO_Best_fitness=mean(log(Times_CDO_Best_fitness)/log(10),1);
CDO_IterCurve=mean(log(Times_CDO_IterCurve)/log(10),1);
OMA_Best_Pos=mean(Times_OMA_Best_Pos,1);
OMA_Best_fitness=mean(log(Times_OMA_Best_fitness)/log(10),1);
OMA_IterCurve=mean(log(Times_OMA_IterCurve)/log(10),1);
GWO31_Best_Pos=mean(Times_GWO31_Best_Pos,1);
GWO31_Best_fitness=mean(log(Times_GWO31_Best_fitness)/log(10),1);
GWO31_IterCurve=mean(log(Times_GWO31_IterCurve)/log(10),1);
MVO_PSO_MIN_MAX_MEAN_BZC =[min(Times_MVO_Best_fitness),max(Times_MVO_Best_fitness),mean(Times_MVO_Best_fitness),std(Times_MVO_Best_fitness)];
GSA_PSO_MIN_MAX_MEAN_BZC =[min(Times_GSA_Best_fitness),max(Times_GSA_Best_fitness),mean(Times_GSA_Best_fitness),std(Times_GSA_Best_fitness)];
WDO_PSO_MIN_MAX_MEAN_BZC =[min(Times_WDO_Best_fitness),max(Times_WDO_Best_fitness),mean(Times_WDO_Best_fitness),std(Times_WDO_Best_fitness)];
GWO_PSO_MIN_MAX_MEAN_BZC =[min(Times_GWO_Best_fitness),max(Times_GWO_Best_fitness),mean(Times_GWO_Best_fitness),std(Times_GWO_Best_fitness)];
CDO_PSO_MIN_MAX_MEAN_BZC =[min(Times_CDO_Best_fitness),max(Times_CDO_Best_fitness),mean(Times_CDO_Best_fitness),std(Times_CDO_Best_fitness)];
OMA_PSO_MIN_MAX_MEAN_BZC =[min(Times_OMA_Best_fitness),max(Times_OMA_Best_fitness),mean(Times_OMA_Best_fitness),std(Times_OMA_Best_fitness)];
GWO31_PSO_MIN_MAX_MEAN_BZC =[min(Times_GWO31_Best_fitness),max(Times_GWO31_Best_fitness),mean(Times_GWO31_Best_fitness),std(Times_GWO31_Best_fitness)];

F11_20cec_MIN_MAX_MEAN_BZC=[MVO_PSO_MIN_MAX_MEAN_BZC;GSA_PSO_MIN_MAX_MEAN_BZC;WDO_PSO_MIN_MAX_MEAN_BZC;GWO_PSO_MIN_MAX_MEAN_BZC ;
    OMA_PSO_MIN_MAX_MEAN_BZC;CDO_PSO_MIN_MAX_MEAN_BZC;GWO31_PSO_MIN_MAX_MEAN_BZC;];
disp(['MVO1_PSO_MIN_MAX_MEAN_BZC??',MVO_PSO_MIN_MAX_MEAN_BZC]);
disp(['GWO_PSO_MIN_MAX_MEAN_BZC??',GWO_PSO_MIN_MAX_MEAN_BZC]);
disp(['GSA_PSO_MIN_MAX_MEAN_BZC??',GSA_PSO_MIN_MAX_MEAN_BZC]);
disp(['WDO_PSO_MIN_MAX_MEAN_BZC??',WDO_PSO_MIN_MAX_MEAN_BZC]);
disp(['CDO_PSO_MIN_MAX_MEAN_BZC??',CDO_PSO_MIN_MAX_MEAN_BZC]);
disp(['OMA_PSO_MIN_MAX_MEAN_BZC??',OMA_PSO_MIN_MAX_MEAN_BZC]);
disp(['GWO31_PSO_MIN_MAX_MEAN_BZC??',GWO31_PSO_MIN_MAX_MEAN_BZC]);
figure
plot(MVO_IterCurve,'-d','MarkerIndices',1:20:length(MVO_IterCurve),'linewidth',1.5);
hold on;
plot(GWO_IterCurve,'-g*','MarkerIndices',1:20:length(GWO_IterCurve),'linewidth',1.5);
hold on;
plot(GSA_IterCurve,'-yp','MarkerIndices',1:20:length(GSA_IterCurve),'linewidth',1.5);
hold on;
plot(WDO_IterCurve,'-b','MarkerIndices',1:20:length(WDO_IterCurve),'linewidth',1.5);
hold on;
plot(CDO_IterCurve,'-ms','MarkerIndices',1:20:length(CDO_IterCurve),'linewidth',1.5);
hold on;
plot(OMA_IterCurve,'-cx','MarkerIndices',1:20:length(OMA_IterCurve),'linewidth',1.5);
hold on;
plot(GWO31_IterCurve,'--ro','MarkerIndices',1:20:length(GWO31_IterCurve),'linewidth',1.5);
hold on;

xlabel('Iteration')
ylabel('Fitness')
title('CEC2019 F11 with D=20')
legend('MVO','GWO','GSA','WDO','CDO','OMA','SZGWO')

