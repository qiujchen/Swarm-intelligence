function o = F50_Fun(x)
t=2*pi*sqrt(sum(x.^2));

o=1-cos(t)+0.1*sqrt(sum(x.^2));
end