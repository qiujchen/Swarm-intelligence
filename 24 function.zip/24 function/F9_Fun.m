function o = F32_Fun(x)
d = length(x);
sum = 0;
for ii = 1:d
    xi = x(ii);
    new = (abs(xi))^(ii+1);
    sum = sum + new;
end
o = sum;
end