function o = F48_Fun(x)
o=x(1).^2+x(2).^2+25*(sin(x(1)).^2+sin(x(2)).^2);

end