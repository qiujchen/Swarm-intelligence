function o = F1_Fun(x)
o=sum(x.^2);
end