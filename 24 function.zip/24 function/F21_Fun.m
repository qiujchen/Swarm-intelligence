function o = F49_Fun(x)
temp=2*x(1)*x(1).^2*x(2)-x(2)*x(2).^2;
temp1=6*x(1)-x(2).^2+x(2);
o=temp.^2+temp1.^2;
end