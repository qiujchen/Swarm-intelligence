function o = F51_Fun(x)
o=7*x(1).^2-6*sqrt(3)*x(1)*x(2)+13*x(2).^2;
end