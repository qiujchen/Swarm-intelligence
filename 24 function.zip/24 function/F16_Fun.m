function o = F42_Fun(x)
dim=size(x,2);
o=10^6*sum(x(2:dim).^2)+x(1).^2;
end