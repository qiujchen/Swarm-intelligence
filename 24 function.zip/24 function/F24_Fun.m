function o =F53_Fun(x)
x1 = x(1);
x2 = x(2);

term1 = 100 * sqrt(abs(x2 - 0.01*x1^2));
term2 = 0.01 * abs(x1+10);
o = term1 + term2;
end