function o = F9_Fun(x)
    dim=length(x);
    o=sum(x.^2-10*cos(2*pi.*x))+10*dim;
end