function o = F43_Fun(x)
temp1=sin(x(1).^2+x(2).^2).^2-0.5;
temp2=1+0.001*(x(1).^2+x(2).^2).^2;
o=0.5+temp1/temp2;
end