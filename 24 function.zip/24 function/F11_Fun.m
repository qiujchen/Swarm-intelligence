function o = F34_Fun(x)
d = length(x);
sum1 = (x(1)-1)^2;
sum2 = 0;

for ii = 2:d
	xi = x(ii);
	xold = x(ii-1);
	sum1 = sum1 + (xi-1)^2;
	sum2 = sum2 + xi*xold;
end
o = sum1 - sum2;
end